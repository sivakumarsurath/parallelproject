package com.capgemini.banktask.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.capgemini.banktask.bean.Account;
import com.capgemini.banktask.bean.Transaction;
import com.capgemini.banktask.exception.BankTaskException;

public class BankTaskDaoImpl implements IBankTaskDao {

	public static Map<Integer, Account> map = new HashMap<>();
	public static Set<Transaction> set = new LinkedHashSet<>();
	static {
		map.put(123456, new Account("hhfhfd", 90000.00, 17291));
		map.put(654321, new Account("jhgjgj", 40000.00, 18434));
		map.put(123465, new Account("trhtrh", 80000.00, 98765));
		map.put(456789, new Account("gfhfh", 100000.00,56788));
	}

	public int getCustomerId() throws BankTaskException {
		double generatedId = Math.random() * 10000;
		int Id = (int) generatedId;
		return Id;

	}

	@Override
	public Map<Integer, Account> addCustomer(int Password, Account account) throws BankTaskException {
		map.put(Password, account);
		return map;
	}

	@Override
	public Map<Integer, Account> getDetails() throws BankTaskException {
		return map;
	}

	@Override
	public long generateAccountNo() throws BankTaskException {

		double generatedId = Math.random() * 10000;
		int Id = (int) generatedId;
		return Id;
	}

	@Override
	public Account checkaccountNo(long accountNo) throws BankTaskException {
		boolean status = false;
		Account acc = null;
		Iterator<Account> iterator = map.values().iterator();
		while (iterator.hasNext()) {
			acc = iterator.next();
			if (acc.getAccountNo() == accountNo) {
				status = true;

			}

			if (status == true) {
				break;
			}

		}
		if (status == false)
			throw new BankTaskException("accountNo not found");
		return acc;
	}

	@Override
	public boolean addTransaction(Transaction transaction) throws BankTaskException {
		set.add(transaction);

		return true;
	}

	@Override
	public Set<Transaction> printTransaction() throws BankTaskException {
		return set;
	}

}
