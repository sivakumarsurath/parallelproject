package com.capgemini.banktask.exception;

public class BankTaskException extends Exception {

	public BankTaskException(String message) {
		super(message);
		
	}
	

}
