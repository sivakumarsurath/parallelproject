package com.capgemini.banktask.dao;

import java.util.Map;
import java.util.Set;

import com.capgemini.banktask.bean.Account;
import com.capgemini.banktask.bean.Transaction;
import com.capgemini.banktask.exception.BankTaskException;

public interface IBankTaskDao {

	int getCustomerId()throws BankTaskException;

	Map<Integer,Account> addCustomer(int Password, Account account)throws BankTaskException;

	Map<Integer, Account> getDetails()throws BankTaskException;

	long generateAccountNo()throws BankTaskException;

	Account checkaccountNo(long accountNo)throws BankTaskException;

	boolean addTransaction(Transaction transaction)throws BankTaskException;

	Set<Transaction> printTransaction() throws BankTaskException;
	
}
