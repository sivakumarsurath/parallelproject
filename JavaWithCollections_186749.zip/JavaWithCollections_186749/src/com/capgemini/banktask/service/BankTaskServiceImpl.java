package com.capgemini.banktask.service;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import com.capgemini.banktask.bean.Account;
import com.capgemini.banktask.bean.Transaction;
import com.capgemini.banktask.dao.BankTaskDaoImpl;
import com.capgemini.banktask.dao.IBankTaskDao;
import com.capgemini.banktask.exception.BankTaskException;

public class BankTaskServiceImpl implements IBankTaskService {

	IBankTaskDao dao = new BankTaskDaoImpl();
	Account customer = null;
	@Override
	public int getCustomerId() throws BankTaskException {

		return dao.getCustomerId();
	}

	@Override
	public Map<Integer, Account> addCustomer(int password, Account account) throws BankTaskException {

		return dao.addCustomer(password, account);
	}

	@Override
	public boolean validLogin(String username, int password, Map<Integer, Account> map)
			throws BankTaskException {
		boolean validLogin = false;
		Set<Integer> set = map.keySet();
		Iterator<Integer> iterator = set.iterator();
		while (iterator.hasNext()) {
			int password1 = iterator.next();
			/* System.out.println(password1); */
			customer = map.get(password1);
			/* System.out.println(customer); */
			String username1 = customer.getName();
			if ((password1 == password && username.equals(username1))) {
				validLogin = true;
				break;
			} else {
				continue;
			}
		}
		if (!validLogin)
		{
			throw new BankTaskException("Invalid Credentials");
		}
		return validLogin;
	}

	@Override
	public Account getAccount() throws BankTaskException {

		return customer;
	}

	@Override
	public boolean withDraw(double wAmount, Account acc) throws BankTaskException {
		boolean validwAmmount = false;
		if (wAmount <= acc.getBalance()) {
			validwAmmount = true;
		} else {
			throw new BankTaskException("Insuffiecient balance in your account");
		}

		return validwAmmount;
	}

	@Override
	public Map<Integer, Account> getDetails() throws BankTaskException {

		return dao.getDetails();
	}

	@Override
	public boolean deposit(double deposit, Account acc) throws BankTaskException {

		boolean validDeposit = false;
		if (deposit < 10000) {
			validDeposit = true;
		} else {
			throw new BankTaskException("amount to be deposited must be less than or equal to 10000");
		}
		return validDeposit;
	}

	@Override
	public long generateAccountNo() throws BankTaskException {

		return dao.generateAccountNo();
	}

	@Override
	public Account checkAccount(long accountNo) throws BankTaskException {

		return dao.checkaccountNo(accountNo);
	}

	@Override
	public int transacId() throws BankTaskException {
		double generatedId = Math.random() * 1000;
		int Id = (int) generatedId;
		return Id;
	}

	@Override
	public boolean addTransaction(Transaction transaction) throws BankTaskException {

		return dao.addTransaction(transaction);
	}

	@Override
	public Set<Transaction> printTransaction() throws BankTaskException {
		
		return dao.printTransaction();
	}

	@Override
	public boolean ValidateName(String Name) throws BankTaskException {
	
		String pattern = "[A-Z]{1}[a-z]{4,}";
		boolean status = false;
		if (!Pattern.matches(pattern, Name)) {
			status = false;
			throw new BankTaskException(
					"Entered name should be start with capital and it should contain atleast 5 letters");
		} else {
			status = true;
		}
		return status;
	}

	@Override
	public boolean validateEmail(String Email) throws BankTaskException {
		
		String pattern = "[a-zA-Z0-9]{4,20}@gmail.com";
		boolean status = false;
		if (!Pattern.matches(pattern, Email)) {
			status = false;
			throw new BankTaskException("Your email id should be in a valid format");
		}
		else {
			status = true;
		}
		return status;
	}

	@Override
	public boolean validatePhoneNumber(String phone) throws BankTaskException {
		String pattern = "[7-9]{1}[0-9]{9}";
		boolean status = false;
		if (!Pattern.matches(pattern, phone)) {
			status = false;
			throw new BankTaskException("Your Phone number must contain digits and should contain 10 digits");
		}
		else {
			status = true;
		}
		return status;
	}

	@Override
	public boolean validateAmount(double ammount) throws BankTaskException {
	
		boolean status = false;
		if(ammount<1000)
		{
			status = false;
			throw new BankTaskException("Your bank account balance should start with minimum amount of 1000 rupees");
		}
		else {
			status = true;
		}
		return status;
	}

	@Override
	public boolean validateTransferAmount(double ammount1) throws BankTaskException {
		boolean validtransferAmmount = false;
		if (ammount1 <= customer.getBalance()) {
			validtransferAmmount = true;
			
		} else {
			
			throw new BankTaskException("Insufficient balance in your account");
		}

		return validtransferAmmount;
	}

	
	
	
	
}
