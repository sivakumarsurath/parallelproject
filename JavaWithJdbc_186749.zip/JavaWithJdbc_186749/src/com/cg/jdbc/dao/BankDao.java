package com.cg.jdbc.dao;

import java.util.List;

import com.cg.jdbc.bean.Account;
import com.cg.jdbc.bean.Customer;
import com.cg.jdbc.bean.Transaction;
import com.cg.jdbc.exception.AccountException;

public interface BankDao {
	int getCustomerId()throws AccountException;
	long generateAccountNo()throws AccountException;
	boolean addAccount(Account account) throws AccountException;
	Account validLogin(String username, long password)throws AccountException;
	boolean withDraw1(double wAmount, Account acc)throws AccountException;
	boolean deposit(double damount, Account acc) throws AccountException;
	boolean addTransaction(Transaction transaction) throws AccountException;
	List<Transaction> viewTransactions(long password) throws AccountException;
	boolean addCustomer(Customer customer) throws AccountException;
}
