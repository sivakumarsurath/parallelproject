package com.cg.jdbc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.jdbc.bean.Account;
import com.cg.jdbc.bean.Customer;
import com.cg.jdbc.bean.Transaction;
import com.cg.jdbc.exception.AccountException;
import com.cg.jdbc.utility.DbConnection;

public class BankDaoImpl implements BankDao {
PreparedStatement statement = null;
	
	int row = -1;
	static Account account= new Account();
	public int getCustomerId() throws AccountException {
		double generatedId = Math.random() * 10000;
		int Id = (int) generatedId;
		return Id;
	}

	public long generateAccountNo() throws AccountException {
		double generatedId = Math.random() * 10000000;
		long Id = (long) generatedId;
		return Id;
	}

	public boolean addAccount(Account account) throws AccountException {
		boolean validate=false;
		try (Connection connection = DbConnection.getConnection();) {

			statement = connection.prepareStatement("select accountseq.NEXTVAL from dual");
			 ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
			validate=true;
				statement = connection.prepareStatement("insert into account1 values(?,?,?,?)");
				statement.setString(1, account.getName());
				
				statement.setDouble(2,account.getBalance());
				statement.setLong(3,account.getAccountNo());
				//statement.setInt(4, account.getPassword());
				
				row = statement.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return validate;
	}

	@Override
	public Account validLogin(String username, long password) throws AccountException{
		
		try (Connection connection = DbConnection.getConnection();) {

			statement = connection.prepareStatement("select*from account1 where NAME=? and PASSWORD=?");
			statement.setString(1, username);
			statement.setLong(2, password);
			
			ResultSet resultSet = statement.executeQuery();
			
			
				if(resultSet.next()){
						System.out.println(resultSet.getString("NAME"));
						account.setName(resultSet.getString("NAME"));
						account.setAccountNo(resultSet.getLong("ACCOUNTNO"));
						account.setBalance(resultSet.getDouble("BALANCE"));
					
						//account.setPassword(resultSet.getInt("PASSWORD"));
				}
		}catch(SQLException e1) {
			System.err.println("username password not exists");
		}
		
		return account;
	}

	@Override
	public boolean withDraw1(double wAmount, Account acc) throws AccountException {
		// TODO Auto-generated method stub
		boolean status=false;
		double amount = acc.getBalance();
		//int password=acc.getPassword();
		amount = amount - wAmount;
		acc.setBalance(amount);
		try (Connection connection = DbConnection.getConnection();) {

			statement = connection
					.prepareStatement("update account1 set BALANCE=? where PASSWORD=?");
			//statement.setInt(2, password);
			statement.setDouble(1, amount);
			row = statement.executeUpdate();
			status=true;
		
	}catch (SQLException e) {
		System.out.println(e.getMessage());
	}
		return status;
	
}

	@Override
	public boolean deposit(double damount, Account acc) throws AccountException {
		// TODO Auto-generated method stub
		boolean status=false;
		double amount = acc.getBalance();
		//int password=acc.getPassword();
		amount = amount + damount;
		try (Connection connection = DbConnection.getConnection();) {

			statement = connection
					.prepareStatement("update account1 set BALANCE=? where PASSWORD=?");
			//statement.setInt(2, password);
			statement.setDouble(1, amount);
			row = statement.executeUpdate();
			status=true;
		
	}catch (SQLException e) {
		System.out.println(e.getMessage());
	}
		return status;
	}

	@Override
	public boolean addTransaction(Transaction transaction) throws AccountException {
		// TODO Auto-generated method stub
		boolean status=false;
		try (Connection connection = DbConnection.getConnection();) {

			statement = connection.prepareStatement("select transacseq.NEXTVAL from dual");
			 ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
			status=true;
				statement = connection.prepareStatement("insert into transaction values(?,?,?,?,?,?,?)");
				statement.setInt(1, transaction.getTransactionId());
				
				statement.setString(2,transaction.getTransactionType());
			//	Date sqldob = new Date(transaction.getTransactionDate().getTime());
				//statement.setDate(3, sqldob);
				statement.setLong(4, transaction.getCustomerid());
				statement.setLong(5, transaction.getAccountNo());
				statement.setDouble(6, transaction.getAmount());
				statement.setDouble(7, transaction.getBalance());
				
				row = statement.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return status;
	}

	

	@Override
	public List<Transaction> viewTransactions(long password) throws AccountException {
		List<Transaction> list1 = new ArrayList<>();
		Transaction transaction=new Transaction();
		try (Connection connection = DbConnection.getConnection();) {

			statement = connection.prepareStatement("select*from transaction where CUSTID=?");
			
			statement.setLong(1, password);
			ResultSet resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
	              transaction.setTransactionId(resultSet.getInt("TRANSACID"));
	              transaction.setTransactionType(resultSet.getString("TRANSACTYPE"));
	           //   transaction.setTransactionDate(resultSet.getDate("DATE1"));
	            //  transaction.setCustomerid(resultSet.getLong("CUSTID"));
	              transaction.setAccountNo(resultSet.getLong("ACCOUNTNO"));
	              transaction.setAmount(resultSet.getDouble("AMOUNT"));
	              transaction.setBalance(resultSet.getDouble("BALANCE"));
	              
System.out.println(transaction);
	              
	        					
				}
			
			} catch (SQLException e) {
				// TODO: handle exception
				System.out.println(e.getMessage());
			}

			return list1;

		
	}

	@Override
	public boolean addCustomer(Customer customer) throws AccountException {
		boolean validate=false;
		try (Connection connection = DbConnection.getConnection();) {

			statement = connection.prepareStatement("select custseq.NEXTVAL from dual");
			 ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
			validate=true;
				statement = connection.prepareStatement("insert into customer values(?,?,?,?,?,?)");
				statement.setInt(1, customer.getCustomerId());
				statement.setString(2, customer.getName());
				
				statement.setString(3,customer.getEmail());
				//statement.setString(4, customer.getMobile());
				statement.setString(5, customer.getAddress());
				statement.setDouble(6, customer.getAmount());
				
				row = statement.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		return validate;
	}
}
