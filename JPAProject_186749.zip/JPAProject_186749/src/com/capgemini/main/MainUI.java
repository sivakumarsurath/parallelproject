package com.capgemini.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bean.Account;
import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.AccountException;
import com.capgemini.service.Service;
import com.capgemini.service.ServiceImpl;

public class MainUI {
	public static void main(String[] args) {
		
	Scanner scanner = new Scanner(System.in);
	Account account = null;
	Transaction transaction = null;
	Service service = new ServiceImpl();
	int transacId = 0;
	Customer customer = null;
	boolean choiceflag = false;
	String continueChoice;
	long accountNo = 0;
	System.out.println("-----------------------------");
	System.out.println("****Welcome to SSK Bank****");
	System.out.println("-----------------------------");
	System.out.println("-----------------------------");

	do {
		System.out.println("1.Create account\n2.Login\n3.Exit");
		System.out.println("Please Select Your Option");
		int choice = 0;
		try {
			choice = scanner.nextInt();
			choiceflag = true;
			switch (choice) {
			case 1: {
				String name = null;
				boolean status1 = false;
				String email = null;
				String phone = null;
				double ammount = 0;
				do {
					try {

						System.out.println("Please Register your user name:");
						name = scanner.next();
						service.ValidateName(name);
						status1 = true;
					} catch (AccountException e) {
						
						status1 = false;
						System.out.println(e.getMessage());
					}
				} while (!status1);

				do {
					try {
						System.out.println("Please Register your email adrress:");
						email = scanner.next();
						service.validateEmail(email);
						status1 = true;
					} catch (AccountException e1) {
						
						status1 = false;
						System.out.println(e1.getMessage());
					}
				} while (!status1);

				do {
					try {
						System.out.println("Please Register your phone number:");
						phone = scanner.next();
						service.validatePhoneNumber(phone);
						status1 = true;
					} catch (AccountException e) {
						
						status1 = false;
						System.out.println(e.getMessage());
					}
				} while (!status1);
				System.out.println("Please Register your Address:");
				String address = scanner.next();
				do {
					try {
						System.out.println("Please Enter the Amount to start your account:");
						ammount = scanner.nextDouble();
						service.validateAmount(ammount);
						status1 = true;
					} catch (AccountException e) {
					
						status1 = false;
						System.out.println(e.getMessage());
					}
				} while (!status1);

				try {
					accountNo = service.generateAccountNo();
					System.out.println("Your accountNo is:" + accountNo);

					int password = service.getCustomerId();
					account = new Account(name, ammount, accountNo, password);
					service.addAccount(account);
					System.out.println("You are registered successfully " + "with the username: " + name + "   "
							+ " and password:" + password);
					customer = new Customer(password, name, email, phone, address, ammount,account);
					service.addCustomer(customer);
				} catch (AccountException e) {

					System.out.println(e.getMessage());
				}
			}
				break;
			case 2: {
				Account acc = null;
				System.out.println("Please Enter Username:");
				String name = scanner.next();
				System.out.println("Please Enter Password:");
				int pass = scanner.nextInt();
				 boolean check = false;
				try {
					check = service.ValidateLogin(name, pass);
					 System.out.println("name: "+name);
                     System.out.println("password: "+pass);
                     System.out.println("check:"+check);
					//acc = service.ValidateLogin(name, pass);
				} catch (AccountException e) {
					
					System.out.println(e.getMessage());
				}
				  if(check) {
				System.out.println("login successfull");
				System.out.println("Enter the required option");
				System.out.println("1.Withdraw\n2.deposit\n3.balance\n4.print Transaction");
				try {
					acc=service.getaccount(name,pass);
				int pass1 = scanner.nextInt();
				double balan = 0;
				switch (pass1) {
				case 1: {
					double bal = 0;
					long acno = 0;
					System.out.println("Enter the amount you want to withdraw:");
					double amt = scanner.nextDouble();
					try {
						service.validateWithdraw(amt);
					} catch (AccountException e) {
						
						System.out.println(e.getMessage());
					}
					try {
						service.withdraw(amt, name, pass);
						bal = acc.getBalance();
						acno = acc.getAccountNo();
						System.out.println("You're Amount has been withdrawn Successfully!" );
					} catch (AccountException e) {
						
						System.out.println(e.getMessage());
					}
					
					try {
						transacId = service.dtransacId();
					} catch (AccountException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
					Date d = new Date();
					String dt = formatter.format(d);
					try {
						d = formatter.parse(dt);
					} catch (ParseException e) {
						
						System.out.println(e.getMessage());
					}

					transaction = new Transaction(transacId, "withdraw", d, pass, acno, amt, bal);
					
					try {
						service.addTransaction(transaction);
					} catch (AccountException e) {
						
						System.out.println(e.getMessage());
					}

				}
					break;
				case 2: {
					System.out.println("Enter the Amount to be deposited in your account:");
					double bal = 0;
					long acno = 0;

					double amt = scanner.nextDouble();
					try {
						service.deposit(amt, name, pass);
						bal = acc.getBalance();
						acno = acc.getAccountNo();

					} catch (AccountException e) {
						
						System.out.println(e.getMessage());
					}
					System.out.println("Amount has been deposited in your Account Successfully!");
					try {
						transacId = service.dtransacId();
					} catch (AccountException e) {
						
						System.out.println(e.getMessage());
					}
					SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
					Date d = new Date();
					String dt = formatter.format(d);
					try {
						d = formatter.parse(dt);
					} catch (ParseException e) {
						
						System.out.println(e.getMessage());
					}

					transaction = new Transaction(transacId, "deposit", d, pass, acno, amt, bal);
					try {
						service.addTransaction(transaction);
					} catch (AccountException e) {
						
						System.out.println(e.getMessage());
					}

				}
					break;

				case 3: {

					try {
						balan = service.getBalance(name, pass);
						System.out.println("Your balance is :" + balan);
					} catch (AccountException e) {
						
						e.printStackTrace();
					}

				}
					break;
				case 4: {
					System.out.println("Your transactions are as mentioned:");
					List<Transaction> list = new ArrayList<Transaction>();
					try {
						list = service.getTransaction(name, pass);
						System.out.println(list);
					} catch (AccountException e) {
						
						e.printStackTrace();
					}
				}
					break;

				default: {
					System.out.println("Sorry! Please enter a valid choice in between 1-4");

				}
					break;
				} 
				}catch(InputMismatchException e) {
					System.err.println("Please enter the choice in digits only!");
					
				}

			}
				break;}
			case 3:{
				System.out.println("Thank You and have a nice day");
				System.exit(0);
			}
			default: {
				System.err.println("enter a valid option between 1-3\n");
			}
				break;
			}
		} catch (InputMismatchException e) {
			choiceflag = true;
			System.out.println("Please enter the choice in digits only!");
		}
		boolean continueValue = false;
		do {

			scanner = new Scanner(System.in);

			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();
			if (continueChoice.equalsIgnoreCase("yes")) {
				continueValue = true;
				choiceflag = true;
				break;

			} else if (continueChoice.equalsIgnoreCase("no")) {
				System.out.println("Thank You ");
				continueValue = false;
				choiceflag = false;
				break;
			} else {
				System.out.println("Enter yes or no");
				continueValue = false;
				continue;
			}
		} while (!continueValue);

	} while (choiceflag);
}
}
