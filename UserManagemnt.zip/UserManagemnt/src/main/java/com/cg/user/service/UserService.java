package com.cg.user.service;

import java.util.List;

import com.cg.user.bean.UserManagement;
import com.cg.user.exception.UserException;

public interface UserService {
	UserManagement addUser(UserManagement userManagement) throws UserException;

	UserManagement getUserById(int id)throws UserException;

	List<UserManagement> updateUser(int id, UserManagement userManagement) throws UserException;

	List<UserManagement> deleteUser(int id) throws UserException;

	List<UserManagement> getAllUsers() throws UserException;

}
