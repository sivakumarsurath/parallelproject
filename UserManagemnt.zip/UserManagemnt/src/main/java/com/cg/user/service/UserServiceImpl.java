package com.cg.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.user.bean.UserManagement;
import com.cg.user.dao.UserDao;
import com.cg.user.exception.UserException;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserDao userDao;
	//private int i=0;

	@Override
	public UserManagement addUser(UserManagement userManagement) throws UserException {
	
		//i++;
		//userManagement.setInd(i);
		return userDao.save(userManagement);
	}

	@Override
	public UserManagement getUserById(int id) throws UserException {
	
		try {
			
			Optional<UserManagement> data=userDao.findById(id);
			if(data.isPresent()) {
				return data.get();
			}else {
				throw new UserException("User with Id "+id+" does not exist");
			}
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
	}

	@Override
	public List<UserManagement> updateUser(int id, UserManagement userManagement) throws UserException {
		
		if(userDao.existsById(userManagement.getId())) {
			userDao.save(userManagement);
			return getAllUsers();
		}else {
			throw new UserException("Invalid User, cannot be  updated");
	}
	}

	
	@Override
	public List<UserManagement> deleteUser(int id) throws UserException {
	
if(userDao.existsById(id)) {
			
	userDao.deleteById(id);
			return getAllUsers();
		}else {
			throw new UserException("cannot delete. User with Id "+id+" does not exist");
		}
	}

	@Override
	public List<UserManagement> getAllUsers() throws UserException {

		try {
			return userDao.findAll();
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
	}
}
