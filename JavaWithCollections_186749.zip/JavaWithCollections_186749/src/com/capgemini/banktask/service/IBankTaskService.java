package com.capgemini.banktask.service;

import java.util.Map;
import java.util.Set;

import com.capgemini.banktask.bean.Account;
import com.capgemini.banktask.bean.Transaction;
import com.capgemini.banktask.exception.BankTaskException;

public interface IBankTaskService {
	int getCustomerId() throws BankTaskException;

	Map<Integer, Account> addCustomer(int password, Account account) throws BankTaskException;

	boolean validLogin(String username, int password, Map<Integer, Account> map) throws BankTaskException;

	Account getAccount() throws BankTaskException;

	boolean withDraw(double wAmount, Account acc) throws BankTaskException;

	Map<Integer, Account> getDetails() throws BankTaskException;

	boolean deposit(double deposit, Account acc) throws BankTaskException;

	long generateAccountNo() throws BankTaskException;

	Account checkAccount(long accountNo) throws BankTaskException;

	int transacId() throws BankTaskException;

	boolean addTransaction(Transaction transaction) throws BankTaskException;

	Set<Transaction> printTransaction() throws BankTaskException;

	boolean ValidateName(String Name) throws BankTaskException;

	boolean validateEmail(String Email) throws BankTaskException;

	boolean validatePhoneNumber(String phone) throws BankTaskException;

	boolean validateAmount(double ammount) throws BankTaskException;

	boolean validateTransferAmount(double ammount1) throws BankTaskException;
}
