package com.capgemini.bean;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Customer {
	@Id
	private int customerId;
	private String name;
	private String email;
	private String mobile;
	private String address;
	private double amount;
	@OneToOne
	private Account account;
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Customer() {
		super();
		
	}

	
	public Customer(int customerId, String name, String email, String mobile, String address, double amount,
			Account account) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.address = address;
		this.amount = amount;
		this.account = account;
	}
	
	@Override
	public String toString() {
		return "Customer [name=" + name + ", email=" + email + ", mobile=" + mobile + ", address=" + address
				+ ", amount=" + amount + "]";
	}
}
