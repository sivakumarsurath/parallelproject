package com.cg.jdbc.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
	private static Connection connection=null;

	public static Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			connection=DriverManager.getConnection(url, "mainp", "mainp");
		} catch (ClassNotFoundException e) {
			
			System.out.println(e.getMessage());
		}catch (SQLException e) {
		
			System.out.println(e.getMessage());
		}
		
		return connection;

}}
