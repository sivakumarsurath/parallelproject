package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Account;
import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.AccountException;

public interface Service {
	boolean ValidateName(String Name) throws AccountException;

	boolean validateEmail(String Email) throws AccountException;

	boolean validatePhoneNumber(String phone) throws AccountException;

	boolean validateAmount(double ammount) throws AccountException;

	int getCustomerId() throws AccountException;

	long generateAccountNo() throws AccountException;

	boolean addAccount(Account account) throws AccountException;

	boolean ValidateLogin(String name, int pass) throws AccountException;

	double getBalance(String name, int pass) throws AccountException;

	boolean validateWithdraw(double amt) throws AccountException;

	boolean withdraw(double amt, String name, int pass) throws AccountException;

	boolean deposit(double amt, String name, int pass) throws AccountException;

	boolean addCustomer(Customer customer) throws AccountException;

	int dtransacId() throws AccountException;

	boolean addTransaction(Transaction transaction) throws AccountException;

	List<Transaction> getTransaction(String name, int pass) throws AccountException;

	Account getaccount(String name, int pass);

}
