package com.capgemini.service;

import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.bean.Account;
import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.dao.DaoImpl;
import com.capgemini.dao.DaoInterface;
import com.capgemini.exception.AccountException;

/**
 * 
 * @author ssurath
 *
 */
public class ServiceImpl implements Service {

	DaoInterface dao = new DaoImpl();

	public boolean ValidateName(String Name) throws AccountException {
		String pattern = "[A-Z]{1}[a-z]{4,}";
		boolean status = false;
		if (!Pattern.matches(pattern, Name)) {
			status = false;
			throw new AccountException(
					"entered name should be start with capital and should contain minimum of 5 letters");
		} else {
			status = true;
		}
		return status;
	}

	public boolean validateEmail(String Email) throws AccountException {
		String pattern = "[a-zA-Z0-9]{4,20}@gmail.com";
		boolean status = false;
		if (!Pattern.matches(pattern, Email)) {
			status = false;
			throw new AccountException("email id should be in valid format ");
		} else {
			status = true;
		}
		return status;
	}

	public boolean validatePhoneNumber(String phone) throws AccountException {
		String pattern = "[7-9]{1}[0-9]{9}";
		boolean status = false;
		if (!Pattern.matches(pattern, phone)) {
			status = false;
			throw new AccountException("phone number must contain 10 digits");
		} else {
			status = true;
		}
		return status;
	}

	public boolean validateAmount(double ammount) throws AccountException {
		boolean status = false;
		if (ammount < 5000) {
			status = false;
			throw new AccountException("your bank account balance should be minimum of 5000 rupees");
		} else {
			status = true;
		}
		return status;
	}

	public int getCustomerId() throws AccountException {
		return dao.getCustomerId();
	}

	public long generateAccountNo() throws AccountException {

		return dao.generateAccountNo();
	}

	public boolean addAccount(Account account) throws AccountException {

		return dao.addAccount(account);
	}

	@Override
	public boolean ValidateLogin(String name, int pass) throws AccountException {

		return dao.ValidateLogin(name, pass);
	}

	@Override
	public double getBalance(String name, int pass) throws AccountException {

		return dao.getBalance(name, pass);
	}

	@Override
	public boolean validateWithdraw(double amt) throws AccountException {

		boolean status = false;
		if (amt > 10000) {
			status = false;
			throw new AccountException("amount should be less than 10000");

		} else {
			status = true;
		}
		return status;
	}

	@Override
	public boolean withdraw(double amt, String name, int pass) throws AccountException {

		return dao.withdraw(amt, name, pass);
	}

	@Override
	public boolean deposit(double amt, String name, int pass) throws AccountException {

		return dao.deposit(amt, name, pass);
	}

	@Override
	public boolean addCustomer(Customer customer) throws AccountException {

		return dao.addCustomer(customer);
	}

	@Override
	public int dtransacId() throws AccountException {

		return dao.generateId();
	}

	@Override
	public boolean addTransaction(Transaction transaction) throws AccountException {

		return dao.addtransaction(transaction);
	}

	@Override
	public List<Transaction> getTransaction(String name, int pass) throws AccountException {

		return dao.getTrans(name, pass);
	}
	 @Override
	    public Account getaccount(String name, int pass) {
	       
	        return dao.getaccount(name,pass);
	    }

}
