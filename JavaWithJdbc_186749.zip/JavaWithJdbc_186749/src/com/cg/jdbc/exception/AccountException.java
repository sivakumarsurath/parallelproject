package com.cg.jdbc.exception;

public class AccountException extends Exception {

	public AccountException() {
		super();
	
	}

	public AccountException(String message) {
		super(message);
		
	}
	

}
