package com.capgemini.banktask.presentation;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.banktask.bean.Account;
import com.capgemini.banktask.bean.Customer;
import com.capgemini.banktask.bean.Transaction;
import com.capgemini.banktask.exception.BankTaskException;
import com.capgemini.banktask.service.BankTaskServiceImpl;
import com.capgemini.banktask.service.IBankTaskService;

public class MainUI {

	public static void main(String[] args) {
		Map<Integer, Account> map = new HashMap<>();
		Map<Integer, Account> map1 = new HashMap<>();
		Scanner scanner = new Scanner(System.in);
		IBankTaskService service = new BankTaskServiceImpl();
		Account account = null;
		Transaction transaction = null;
		int transacId = 0;
		Customer customer = null;
		boolean choiceflag = false;
		String continueChoice;
		long accountNo = 0;
		System.out.println("****Welcome to HDFC Bank****");
		System.out.println("-----------------------------");
		System.out.println("-----------------------------");
		System.out.println("choose your option");

		do {

			System.out.println("1.Create account\n2.Login\n3.Exit");
			System.out.println("enter your choice:");
			int choice = 0;
			try {
				choice = scanner.nextInt();
				choiceflag = false;
				switch (choice) {
				case 1: {
					String name = null;
					boolean status1 = false;
					String email = null;
					String phone = null;
					double amount = 0;
					do {
						try {

							System.out.println("Register your user name:");
							name = scanner.next();
							service.ValidateName(name);
							status1 = true;
						} catch (BankTaskException e) {

							status1 = false;
							System.out.println(e.getMessage());
						}
					} while (!status1);
					do {
						try {
							System.out.println("Register your email adrress:");
							email = scanner.next();
							service.validateEmail(email);
							status1 = true;
						} catch (BankTaskException e1) {

							status1 = false;
							System.out.println(e1.getMessage());
						}
					} while (!status1);

					do {
						try {
							System.out.println("Register your phone number:");
							phone = scanner.next();
							service.validatePhoneNumber(phone);
							status1 = true;
						} catch (BankTaskException e) {

							status1 = false;
							System.out.println(e.getMessage());
						} catch (InputMismatchException e) {

							System.err.println("enter the digits only");
						}
					} while (!status1);
					System.out.println("Register your Address:");
					String address = scanner.next();
					do {
						try {
							System.out.println("Please Enter the Amount to start your account:");
							amount = scanner.nextDouble();

							status1 = service.validateAmount(amount);

						} catch (BankTaskException e) {
							status1 = false;
							System.out.println(e.getMessage());
							scanner.nextLine();
						} catch (InputMismatchException e) {
							status1 = false;
							System.err.println("please enter the amount in digits format only\n");
							scanner.nextLine();
						}

					} while (!status1);

					try {
						accountNo = service.generateAccountNo();
						System.out.println("your AccountNo is:" + accountNo);
						account = new Account(name, amount, accountNo);
						int password = service.getCustomerId();
						map = service.addCustomer(password, account);
						System.out.println("You are Registered successfully " + "with the Username: " + name + "   "
								+ "and Password:" + password);
						customer = new Customer(password, name, email, phone, address, amount, account);
					} catch (BankTaskException e) {

						System.out.println(e.getMessage());
					}
				}
					break;
				case 2: {
					scanner.nextLine();
					try {
						map1 = service.getDetails();

					} catch (BankTaskException e1) {
						System.out.println(e1.getMessage());
					}
					boolean validLogin = false;
					do {
						System.out.println("Enter Username:");
						String username = scanner.next();
						System.out.println("Enter Password:");
						int password = scanner.nextInt();
						scanner.nextLine();

						try {
							service.validLogin(username, password, map1);
							Account acc = service.getAccount();
							validLogin = true;
							System.out.println(
									"1.Withdraw\n2.Show balance\n3.Deposit\n4.Fund transfer\n5.Print Transaction");
							int choice1 = 0;
							System.out.println("enter choice:");
							try {
								choice1 = scanner.nextInt();
								switch (choice1) {
								case 1: {
									boolean validAmount = false;
									double withdrawnAmount = 0;
									do {
										try {
											System.out.println("Enter the amount to be withdrawn:");
											withdrawnAmount = scanner.nextDouble();
											service.withDraw(withdrawnAmount, acc);
											validAmount = true;

										} catch (BankTaskException e) {
											System.out.println(e.getMessage());
										}
									} while (!validAmount);
									double amount = acc.getBalance();
									amount = amount - withdrawnAmount;
									acc.setBalance(amount);
									System.out.println("you have withdrawn an amount of:" + withdrawnAmount);
									String checkbalance;
									System.out.println("do you want to see the available balance");
									checkbalance = scanner.next();
									if (checkbalance.equalsIgnoreCase("yes")) {
										System.out.println("available balance in your account is:" + amount);
									}
									SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
									Date d = new Date();
									String dt = formatter.format(d);
									transacId = service.transacId();
									transaction = new Transaction(transacId, "withdraw", dt, password, accountNo,
											withdrawnAmount, amount);
									System.out.println(transaction);
									service.addTransaction(transaction);

								}
									break;
								case 2: {
									System.out.println("Available amount in your account is:" + acc.getBalance());

								}
									break;
								case 3: {
									boolean validAmount = false;
									double deposit = 0;
									do {
										try {
											System.out.println("Enter amount to be deposited in your account:");
											deposit = scanner.nextDouble();
											service.deposit(deposit, acc);
											validAmount = true;

										} catch (BankTaskException e) {
											System.out.println(e.getMessage());
										}
									} while (!validAmount);
									double amount = acc.getBalance();
									amount = amount + deposit;
									acc.setBalance(amount);
									System.out.println("amount deposited in your account is:" + deposit);
									String checkbalance;
									System.out.println("do you want to show available balance");
									checkbalance = scanner.next();
									if (checkbalance.equalsIgnoreCase("yes")) {
										System.out.println("available balance in your account:" + amount);
									}
									SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
									transacId = service.transacId();
									Date d = new Date();
									String dt = formatter.format(d);
									transaction = new Transaction(transacId, "deposit", dt, password, accountNo,
											deposit, amount);
									service.addTransaction(transaction);
								}
									break;
								case 4: {
									scanner.nextLine();
									boolean checkAccount = false;
									do {
										System.out.println("Enter the accountNo to which amount to be transferred:");
										long accountNo1 = scanner.nextLong();
										System.out.println("Enter name of the account holder:");
										String name = scanner.next();
										try {
											Account account1 = service.checkAccount(accountNo1);
											System.out.println("Enter amount to be transferred:");
											double ammount1 = scanner.nextDouble();
											service.validateTransferAmount(ammount1);
											double Amount = account1.getBalance();
											System.out.println(Amount);
											Amount = Amount + ammount1;
											account1.setBalance(Amount);
											System.out.println("amount transferred successfully");

											double amo = acc.getBalance();
											amo = amo - ammount1;
											acc.setBalance(amo);
											System.out.println("after fund transfer your balance is: " + amo);
											checkAccount = true;
											SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
											Date d = new Date();
											String dt = formatter.format(d);
											transacId = service.transacId();
											transaction = new Transaction(transacId, "fund transfer", dt, password,
													accountNo1, ammount1, amo);
											service.addTransaction(transaction);
										} catch (BankTaskException e) {
											System.out.println(e.getMessage());
										}

									} while (!checkAccount);
								}
									break;
								case 5: {
									System.out.println("your transactions are as mentioned:");
									Set<Transaction> st11 = service.printTransaction();
									System.out.println(st11);

								}
									break;
								default: {
									System.out.println("please enter a valid choice between 1-5");
								}
									break;
								}
								//here
								  boolean validLogin1 = false; 
								  do { 
									  scanner = new Scanner(System.in);
								  System.out.println("do you want to continue the Session [Y/N]");
								  continueChoice = scanner.nextLine();
								  if
								  (continueChoice.equalsIgnoreCase("Y"))
								  { validLogin1 = true; 
								  validLogin=false;
								  choiceflag =
								  true; break;
								  } else
									  if (continueChoice.equalsIgnoreCase("N"))
									  {
								  System.out.println("thank you");
								  validLogin1 = false;
								  validLogin=true;
								  break; 
								  } else {
								  System.out.println("enter Y or N"); validLogin1 = false; continue; } } while
								  (!validLogin1);
								 
//end
							} catch (InputMismatchException e) {

								System.out.println("please enter the choice in digits");
							}
						} catch (BankTaskException e) {
							System.out.println(e.getMessage());
						}
					} while (!validLogin);

				}
					break;
				case 3: {
					System.out.println("Thank You and have a nice day");
					System.exit(0);

				}
					break;
				default: {
					System.err.println("choice must be 1,2,3");
					choiceflag = true;
				}
					break;
				}
				boolean continueValue = false;
				do {
					scanner = new Scanner(System.in);
					System.out.println("do you want to continue the Session [Y/N]");
					continueChoice = scanner.nextLine();
					if (continueChoice.equalsIgnoreCase("Y")) {
						continueValue = true;
						choiceflag = true;
						break;
					} else if (continueChoice.equalsIgnoreCase("N")) {
						System.out.println("thank you");
						continueValue = false;
						break;
					} else {
						System.out.println("enter Y or N");
						continueValue = false;
						continue;
					}
				} while (!continueValue);

			} catch (InputMismatchException e) {
				choiceflag = true;
				System.err.println("please enter digits\n");
				scanner.nextLine();
			}

		} while (choiceflag);
		scanner.close();

	}

}
