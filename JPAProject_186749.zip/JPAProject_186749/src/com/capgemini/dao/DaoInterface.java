package com.capgemini.dao;

import java.util.List;

import com.capgemini.bean.Account;
import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.AccountException;

public interface DaoInterface  {
	int getCustomerId()throws AccountException;
	long generateAccountNo()throws AccountException;
	boolean addAccount(Account account) throws AccountException;
	boolean ValidateLogin(String name, int pass) throws AccountException;
	double getBalance(String name, int pass) throws AccountException;
	boolean withdraw(double amt, String name, int pass) throws AccountException;
	boolean deposit(double amt, String name, int pass) throws AccountException;
	boolean addCustomer(Customer customer) throws AccountException;
	int generateId() throws AccountException;
	boolean addtransaction(Transaction transaction) throws AccountException;
	List<Transaction> getTrans(String name, int pass) throws AccountException;
	Account getaccount(String name, int pass);
	
}
